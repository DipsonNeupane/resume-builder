# Staging rehearsal — exact commands and expected results

**Status: prepared, not executed.** Nothing in this file has been run against any hosted
environment. Every step needs the owner's approval and staging credentials. "No existing users"
does not authorize deleting remote data, objects or resources.

Placeholders (never commit their values): `STAGING_REF` (Supabase project ref of the
**staging** project), `STAGING_DB_URL` (its direct Postgres connection string),
`PREVIEW_URL` (the Vercel preview URL). Tools needed on the operator's machine: Supabase CLI,
`psql`, Vercel CLI. None of them are installed on the machine that prepared this package.

## 0. Preconditions

| Check | How | Expected |
|---|---|---|
| Staging is a separate project | Supabase dashboard → project settings | `STAGING_REF` differs from the production ref |
| Working tree is the reviewed one | `git -C <worktree> rev-parse HEAD` and `git status --short \| wc -l` | the commit the owner approved (this package was prepared on uncommitted work over `1a883b6`) |
| No contract file in migrations | `ls supabase/migrations \| grep contract` | no output (the contract step lives in `supabase/contract/`) |

## 1. Record the starting point (read-only)

```sh
supabase link --project-ref "$STAGING_REF"
supabase migration list --linked              # save the output with the rehearsal notes
psql "$STAGING_DB_URL" -v ON_ERROR_STOP=1 -f supabase/checks/hosted_preflight.sql   > preflight.txt
psql "$STAGING_DB_URL" -v ON_ERROR_STOP=1 -f supabase/checks/tracker_rehearsal_before.sql > before.txt
```

Expected: every migration up to `20261013160000` listed as applied both locally and remotely;
none of `20261027100000…160000` applied. In `before.txt`, `launch_migrations_recorded = 0`, and
the `application_status, decision` counts and `history_rows` are recorded for comparison.

## 2. Back up staging

Dashboard → Database → Backups → create a backup, **or**
`supabase db dump --linked -f staging-before-launch.sql` (schema) plus
`supabase db dump --linked --data-only -f staging-before-launch-data.sql` (data). Store outside
the repository. Expected: backup or dump files exist and are non-empty.

## 3. Apply the five launch migrations (staging only)

```sh
supabase db push --linked --dry-run   # must list exactly the five files below, nothing else
supabase db push --linked
```

Expected dry-run list, in order: `20261027100000_launch_allowance_status.sql`,
`20261027120000_application_tracker.sql`, `20261027140000_free_tailoring_trial.sql`,
`20261027150000_requirement_edits.sql`, `20261027160000_saved_match_preview.sql`. Stop if any
other file appears.

## 4. Check the result (read-only)

```sh
psql "$STAGING_DB_URL" -v ON_ERROR_STOP=1 -f supabase/checks/tracker_rehearsal_after.sql > after.txt
```

| Output | Expected | Meaning |
|---|---|---|
| `launch_migrations_recorded` | 5 | all five applied and recorded |
| `stage, closed_reason, rows` | totals equal the `before.txt` row totals | every existing workflow row converted; none lost |
| `stage_legacy_disagreements` | 0 | the new `stage` and the kept legacy columns agree |
| `closed_without_reason` | 0 | every closed record has a reason |
| `browser_grants` | 0 | browser roles cannot read tracker, settings or trial tables |
| `free_application_limit` | 100 | tracked applications per Free account (all stages count; no reset window) |
| `free_tailoring_trials` | 1 | complete tailoring trials per Free account (lifetime; no reset) |
| `free_trial_ai_runs` | 3 | successful AI suggestion runs inside that one trial (failed runs don't count) |
| `events` vs `legacy_history_rows` | `events` ≥ `legacy_history_rows` | history backfilled into events |

The same checks ran locally against fictional rows (`node scripts/rehearse-tracker-migrations.mjs`;
full output in `test-results/08-migration-rehearsal.txt`): all expected values were met.

## 5. Deploy a preview against staging and verify live behavior

Set preview-scoped environment variables to the **staging** Supabase project (names only:
`SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `VITE_SUPABASE_URL`,
`VITE_SUPABASE_PUBLISHABLE_KEY`, `APP_ORIGIN`, `EXPORTS_ENABLED`, `AI_ENABLED`, `OPENAI_API_KEY`,
`TECHMAP_API_KEY`, `VITE_PAID_FEATURES_UI_ENABLED`, `VITE_BILLING_UI_ENABLED`, Stripe **test-mode**
keys, and for reminders `RESEND_API_KEY`, `BILLING_EMAIL_FROM`, `CRON_SECRET` or
`NOTICE_DISPATCH_SECRET`), then `vercel deploy` (preview, never `--prod`).

The local browser suites use a mocked Auth endpoint and cannot point at a preview, so these are
manual checks with **fictional** accounts. Each currently has the status **unverified**.

| # | Live check (fictional accounts A and B) | Expected |
|---|---|---|
| L1 | Signed out, open `PREVIEW_URL/workspace/applications` | "Sign in to track applications."; no account data; `/api/jobs-account` not called with a token |
| L2 | Sign in as A with a wrong password, then the right one, from that prompt | error, then back on `/workspace/applications` (authentication return) |
| L3 | Email sign-up confirmation and password-recovery links for a new fictional address | links arrive and return to `PREVIEW_URL` (checks hosted Auth redirect URLs) |
| L4 | A: quick add, Prepare (free trial), edit the job-specific summary; reload | same version and edit; master unchanged |
| L5 | A: sign out on this device; call `/api/jobs-account` with A's old access token | UI shows no draft; API returns 401 (token revoked) |
| L6 | Sign in as B; open A's version URL | "This workspace item is unavailable."; B's list is empty |
| L7 | Sign out B, sign in A on the version URL | A's draft is back |
| L8 | Discover search with real Techmap data | results ranked; cards show fit/unknown reasons |
| L9 | Tailoring with real OpenAI output on 3+ fictional resumes | traceable suggestions; unsupported ones say "Needs your support" and have no Accept |
| L10 | PDF export in the deployed function | PDF opens; text selectable; content matches the job-specific version |
| L11 | Stripe test-mode checkout, portal cancel, renewal webhook | Pro granted; cancellation keeps access to period end |
| L12 | Renewal reminder: a test-mode subscription whose period ends in ≤3 days; trigger `/api/dispatch-billing-notices` with the cron secret | one email received at the fictional address stating the renewal date; a second trigger sends nothing |
| L13 | `www.` host on the preview domain (if configured) | 301 to apex |

Only after L12 passes may the owner decide whether to add a reminder promise back to the terms
(it was removed from launch-facing copy because delivery is unverified).

## 6. Rehearse an app rollback (no database restore)

Deploy the previous release (the commit currently in production — record it from the Vercel
dashboard; this package did not check it) as a second preview against the **same** staging database. Expected: it loads; saved jobs created by
the new release appear with their stage (the legacy sync trigger keeps `decision` /
`application_status` in step); a stage change made by the old release shows correctly in the new
preview afterwards. Known limits: the old release cannot show manual (no-URL) applications,
events, kept documents, next actions, the trial or requirement edits.

## 7. Do not apply the contract step in this window

`supabase/contract/20261110000000_application_tracker_contract.sql` drops the legacy columns,
history table, legacy RPCs and sync trigger. After it runs, the previous release can no longer
run and rollback means restoring a backup. Apply it only in production, after the new release has
run long enough that rollback is no longer wanted, with a fresh backup and explicit approval:

```sh
psql "$PROD_DB_URL" -v ON_ERROR_STOP=1 -1 -f supabase/contract/20261110000000_application_tracker_contract.sql
```

Locally, `npm run test:db` applies the contract file after the full suite and reruns every test
file except the legacy-sync test; it passes (see `test-results/04-database-tests.txt`).

## 8. Migration and rollback notes

| File | Kind | Rollback |
|---|---|---|
| `20261027100000_launch_allowance_status` | replaces `pdf_status` | redefine the previous function from `20261013160000` |
| `20261027120000_application_tracker` | **expand**: new columns (backfilled), events, kept documents, settings, RPCs, legacy sync trigger; legacy columns kept | app rollback works without restore (§6); schema rollback has no down-migration — restore from the §2 backup |
| `20261027140000_free_tailoring_trial` | additive tables + replaced functions | as above |
| `20261027150000_requirement_edits` | additive column + replaced functions | as above |
| `20261027160000_saved_match_preview` | replaces `jobs_account_snapshot_v2` | redefine the previous function |
| `supabase/contract/…` | **contract**, destructive | restore from backup only |

Rationale for each dropped legacy object, and why the drop is a separate later step, is in
`docs/apwico-implementation-progress.md` §6.
